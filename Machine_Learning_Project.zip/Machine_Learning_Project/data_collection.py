import time
import pandas as pd
import numpy as np
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait,Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys


def get_html_elem(driver_obj,xpath,delay):
    try:
        elem = None
        elem = WebDriverWait(driver_obj,delay).until(
            EC.presence_of_element_located((By.XPATH,xpath))
        )
    except Exception as e:
        logging.error(e)
    return elem

def extract_data():
    try:
        


        final_data = pd.DataFrame()  # Final dataframe to store
                                    # all the player data

        # Looping through all the players
        player_dict = {"Virat":"V+Kohli","DavidWarner":"DA+Warner","KaneWilliamson":"KS+Williamson",
                    "Bhuvneshwar":"B+Kumar","RohitSharma":"RG+Sharma",
                    "HKlaasen":"H+Klaasen","Rashid":"Rashid+Khan","Shami":"Mohammed+Shami"}


        for pname,pvalue in player_dict.items():
            driver = webdriver.Chrome()
            # Accessing the web page for the current player's stats
            url = "http://www.cricmetric.com/playerstats.py?player={}&role=all&format=TWENTY20&groupby=match&playerStatsFilters=on&start_date=2002-01-01&end_date=2023-05-18&start_over=0&end_over=9999".format(pvalue)
            #print(url)
            driver.get(url)
            
            # Scrolling down to load all the stats
            driver.execute_script("window.scrollTo(0, 1080)")
            driver.maximize_window()
            time.sleep(10)
            
            try:
                # Extracting batting stats of the player

                batting_table = get_html_elem(driver,
                    '//*[@id="TWENTY20-Batting"]/div/table',5)
                bat = batting_table.text
                stats = pd.DataFrame(bat.split('\n'))[0].str.split(' ',
                                                                    expand=True)[0:-1]
                stats.columns = stats.iloc[0]
                stats = stats[1:]
                del stats['%']
                stats = stats[['Match','Runs','Balls','Outs','SR',
                            '50','100','4s','6s','Dot']]
                stats.columns = ['Match','Runs Scored','Balls Played',
                                'Out','Bat SR','50','100','4s Scored',
                                '6s Scored','Bat Dot%']
                
                # Switching to bowling stats tab
                bowling_tab = get_html_elem(driver,
                    '//*[@id="TWENTY20-Bowling-tab"]',5)
                bowling_tab.click()
                time.sleep(10)
                
                # Extracting bowling stats of the player
                bowling_table = get_html_elem(driver,
                    '//*[@id="TWENTY20-Bowling"]/div/table',5)
                bowl = bowling_table.text
                stats2 = pd.DataFrame(bowl.split('\n'))[0].str.split(' ',
                                                                    expand=True)[0:-1]
                stats2.columns = stats2.iloc[0]
                stats2 = stats2[1:]
                stats2 = stats2[['Match','Overs','Runs','Wickets','Econ',
                                'Avg','SR','5W','4s','6s','Dot%']]
                stats2.columns = ['Match','Overs Bowled','Runs Given',
                                'Wickets Taken','Econ','Bowl Avg',
                                'Bowl SR','5W','4s Given','6s Given',
                                'Bowl Dot%']
                
            except Exception as e:
                # If stats for current player not found,
                # create empty dataframe
                stats2 = pd.DataFrame({'Match':pd.Series(stats['Match'][0:1]),
                                    'Overs Bowled':[0],'Runs Given':[0],
                                    'Wickets Taken':[0],'Econ':[0],
                                    'Bowl Avg':[0],'Bowl SR':[0],'5W':[0],
                                    '4s Given':[0],'6s Given':[0],
                                    'Bowl Dot%':[0]})
                logging.error(e)
                
            # Merge batting and bowling stats
            logging.info("-------------------------------------{}-------------------------------------------".format(pname))
            logging.info(len(stats))
            logging.info(len(stats2))
            
            merged_stats = pd.merge(stats,stats2,on='Match',how='outer').fillna(0)
            merged_stats = merged_stats.sort_values(by=['Match'])
            logging.info(len(merged_stats))
            logging.info("-------------------------------------{}-------------------------------------------".format(pname))
            # Create lagged variables for future performance prediction
            merged_stats.insert(loc=0, column='Player', value=pname)
            merged_stats['next_runs'] = merged_stats['Runs Scored'].shift(-1)
            merged_stats['next_balls'] = merged_stats['Balls Played'].shift(-1)
            merged_stats['next_overs'] = merged_stats['Overs Bowled'].shift(-1)
            merged_stats['next_runs_given'] = merged_stats['Runs Given'].shift(-1)
            merged_stats['next_wkts'] = merged_stats['Wickets Taken'].shift(-1)
            final_data = final_data.append(merged_stats)
            driver.quit()
        final_data = final_data[final_data['Match']!=0]

        final_data['Bowl Avg'] = np.where(final_data['Bowl Avg']=='-',
                                        0,final_data['Bowl Avg'])
        final_data['Bowl SR'] = np.where(final_data['Bowl SR']=='-',
                                        0,final_data['Bowl SR'])
        final_data = final_data[['Player','Match', 'Runs Scored',
                                'Balls Played', 'Out', 'Bat SR',
                                '50', '100', '4s Scored',
                                '6s Scored','Bat Dot%',
                                'Overs Bowled','Runs Given',
                                'Wickets Taken', 'Econ',
                                'Bowl Avg', 'Bowl SR', '5W',
                                '4s Given', '6s Given',
                                'Bowl Dot%', 'next_runs',
                                'next_balls', 'next_overs',
                                'next_runs_given', 'next_wkts']]
        final_data = final_data.replace('-',0)
        final_data.to_csv('data/test.csv',index=False)

    
    except Exception as e:
        logging.error(e)
    

def start_process():

    LOG_FILENAME = 'logs/data_collect2.log'
    logging.basicConfig(filename=LOG_FILENAME,level=logging.INFO,filemode='a',
                        format='%(asctime)-15s:: %(process)d -%(module)s:%(lineno)d:: %(levelname)-7s :: %(message)s')
    logger = logging.getLogger(__name__)
    extract_data()
    #logging.info("Appended")

start_process()


